import java.net.*;
class Inetdemo
{
	public static void main(String args[])
	throws UnknownHostException
	{
		InetAddress addr1=InetAddress.getLocalHost();
		System.out.println("LOCAL_HOST:"+addr1);
		
		InetAddress addr2=InetAddress.getByName("www.irctc.co.in");
		System.out.println("NAME:"+addr2);
		
	}
}